#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void print_words()
{	
	int words_long = 5;
	char board[15][15];
	char words[93][words_long];
	FILE *fp = fopen("wordlist.txt","r");
	for(int i=0 ; i<50 ; i++) // KELİMELER WORDS ARRAYINA ATANDI
	{
		fscanf(fp,"%s",words[i]);
	}
	int counter=0;
	int sequence[7]; // SEÇİLECEK KELİMELERİN İNDEX NUMARASI BU ARRAYIN İÇİNE ATANICAK
	int random = rand() % 50 + 1;
	sequence[counter]=random;
	int temp=0;
	int size[7];

	// SEÇİLEN İNDEX NUMARALARIN FARKLI OLMASINI SAĞLICAK KISIM
	if (counter==0)
	{
		sequence[counter]=random;
		size[counter]=strlen(words[sequence[counter]]);
		counter++;
	}
	if(counter==1)
	{	
		random = rand() % 50 + 1;
		for(int i=0 ; i<counter ; i++)
		{
			while(sequence[i]==random)
			{
				random = rand() % 50 + 1;
			}
			sequence[counter]=random;
		}
		size[counter]=strlen(words[sequence[counter]]);
		counter++;
	}

	if (counter==2)
	{
		int temp ;
		random = rand() % 50 + 1;
		for(int i=0 ; i<counter;i++)
		{
			while(sequence[i]==random)
			{
				random = rand() % 50 + 1;
			}
			temp=random;
		}
		sequence[counter]=temp;
		size[counter]=strlen(words[sequence[counter]]);
		counter++;
	}

	if(counter==3)
	{
		int temp ;
		random = rand() % 50 + 1;
		for(int i=0 ; i<counter;i++)
		{
			while(sequence[i]==random)
			{
				random = rand() % 50 + 1;
			}
			temp=random;
		}
		sequence[counter]=temp;
		size[counter]=strlen(words[sequence[counter]]);
		counter++;
	}

	if (counter==4)
	{
		int temp ;
		random = rand() % 50 + 1;
		for(int i=0 ; i<counter;i++)
		{
			while(sequence[i]==random)
			{
				random = rand() % 50 + 1;
			}
			temp=random;
		}
		sequence[counter]=temp;
		size[counter]=strlen(words[sequence[counter]]);
		counter++;
	}

	if (counter==5)
	{
		int temp ;
		random = rand() % 50 + 1;
		for(int i=0 ; i<counter;i++)
		{
			while(sequence[i]==random)
			{
				random = rand() % 50 + 1;
			}
			temp=random;
		}
		sequence[counter]=temp;
		size[counter]=strlen(words[sequence[counter]]);
		counter++;
	}
	
	if (counter==6)
	{
		int temp ;
		random = rand() % 50 + 1;
		for(int i=0 ; i<counter;i++)
		{
			while(sequence[i]==random)
			{
				random = rand() % 50 + 1;
			}
			temp=random;
		}
		sequence[counter]=temp;
		size[counter]=strlen(words[sequence[counter]]);
		counter++;
	}
	for(int i=0 ; i<7 ; i++)
	{
		printf("%d \n ",sequence[i]);
	}

	int line[7];
	int column[7];
	for(int i=0 ; i<7 ; i++)
	{
		int direction =rand() % 8 + 1;
		if(direction==1) // yatay düz   -- horizontal straight
		{
			column[i] = rand() % 15 + 0; // BAŞLANACAK SATIR İNDEXİ
			line[i] = rand() % 10 + 0 ;  // SOLDAN SAĞA BAŞLANACAK İLK İNDEX NUMARASI

			//BOARD ÜZERİNE SOLDAN SAĞA DÜZ ŞEKİLDE YAZDIRMA
			for(int k=0; k<size[i];k++)
			{
				board[line[i]][column[k]]=words[sequence[i]][k];
			}
			
		}
		else if(direction==2) // yatay ters  --  horizantal reverse
		{	
			column[i] = rand() % 15 + 0;	// BAŞLANACAK SATIR İNDEXİ
			line[i] = rand() % 15 + 5 ;		// SAĞDAN SOLA BAŞLANACAK İLK İNDEX NUMARASI

			//BOARD ÜZERİNE SAĞDAN SOLA DÜZ ŞEKİLDE YAZDIRMA
			for(int k = 0 ; k<size[i] ; k++)
			{
				board[line[i]][column[i]]=words[sequence[i]][k];
				column[i]--;
			}
		}
		else if(direction==3)  // dikey  düz   -- vertical straight
		{
			line[i] = rand() % 15 + 0 ;	    // BAŞLANACAK SUTUN İNDEKSİ
			column[i] = rand() % 10 + 0;	// YUKARIDAN AŞAĞIYA İLK BAŞLANACAK İNDEX NUMARASI

			//BOARD ÜZERİNE YUKARIDAN AŞAĞIYA DÜZ YAZDIRMA
			for (int k = 0 ; k<size[i] ; k++)
			{
				board[line[k]][column[i]]=words[sequence[i]][k];
			}
		}
		else if(direction==4)  // dikey ters   --  vertical reverse
		{
			line[i] = rand() % 15 + 0 ;	    // BAŞLANACAK SUTUN İNDEKSİ
			column[i] = rand() % 15 + 5;	// AŞAĞIDAN YUKARI İLK BAŞLANACAK İNDEX NUMARASI

			//BOARD ÜZERİNE AŞAĞIDAN YUKARI DÜZ YAZDIRMA
			for(int k = 0 ; k<size[i] ; k++)
			{
				board[line[i]][column[i]]=words[sequence[i]][k];
				line[i]--;
			}	
		}
		else if(direction==5)  // çapraz yukarıdan aşağı sağa doğru   -- diagonally from top to bottom right
		{
			line[i] = rand() % 10 + 0 ;	    // SAĞDAN SOLA BAŞLANACAK İLK İNDEX NUMARASI
			column[i] = rand() % 10 + 0;	// YUKARIDAN AŞAĞI İLK BAŞLANACAK İNDEX NUMARASI		
			
			//BOARD ÜZERİNE YUKARIDAN SAĞA ÇAPRAZA DOĞRU
			for(int k=0 ; k<size[i];k++)
			{
				board[line[i]][column[i]]=words[sequence[i]][k];
				line[i]++;
				column[i]++;
			}
		}

		else if(direction==6)  // çapraz yukarıdan aşağı sola doğru   -- diagonally from top to bottom left
		{
			line[i] = rand() % 15 + 5 ;	    // SOLDAN SAĞA BAŞLANACAK İLK İNDEX NUMARASI
			column[i] = rand() % 10 + 0;	// YUKARIDAN AŞAĞI İLK BAŞLANACAK İNDEX NUMARASI

			//BOARD ÜZERİNDE YUKARIDAN SOL ÇAPRAZA DOĞRU
			for(int k=0 ; k<size[i];k++)
			{
				board[line[i]][column[i]]=words[sequence[i]][k];
				line[i]++;
				column[i]--;
			}

		}	
		else if(direction==7)  // çapraz aşağıdan yukarı sağa doğru   -- diagonally from bottom to top right
		{
			line[i] = rand() % 10 + 0 ;	    // SAĞDAN SOLA BAŞLANACAK İLK İNDEX NUMARASI
			column[i] = rand() % 15 + 5;	// AŞAĞIDAN YUKARI İLK BAŞLANACAK İNDEX NUMARASI

			//BOARD ÜZERİNDE AŞAĞIDAN  YUKARIYA SAĞ ÇAPRAZA DOĞRU
			for(int k=0 ; k<size[i];k++)
			{
				board[line[i]][column[i]]=words[sequence[i]][k];
				line[i]--;
				column[i]++;
			}

		}
		else if(direction==8)  // çapraz aşağıdan yukarı sola doğru   -- diagonally from bottom to top left
		{
			line[i] = rand() % 15 + 5 ;	    // SOLDAN SAĞA BAŞLANACAK İLK İNDEX NUMARASI
			column[i] = rand() % 15 + 5;	// AŞAĞIDAN YUKARI İLK BAŞLANACAK İNDEX NUMARASI
			
			//BOARD ÜZERİNDE AŞAĞIDAN YUKARIYA SOL ÇAPRAZA DOĞRU
			for(int k=0 ; k<size[i];k++)
			{
				board[line[i]][column[i]]=words[sequence[i]][k];
				line[i]--;
				column[i]--;
			}
		}	
	}
	char character[25]={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','r','s','t','u','v','w','x','y','z'};
	
	int random_char;
	for(int i=0;i<15;i++)
	{
		for(int k=0 ; i<15 ; i++)
		{
			for(int j=0 ; j<25 ; j++)
			{
				if(board[i][k]!=character[j])
				{
					random_char=rand() % 25 ;
					board[i][k]=character[random_char];
				}
			}
		}
	}

	for(int i=0 ; i<15 ; i++)
	{
		for (int k = 0; k < 15; k++)
		{
			printf("%c ",board[i][k]);
		}
		printf("\n");
	}
}
int main()
{

	
	print_words();	
	

	return 0;
}