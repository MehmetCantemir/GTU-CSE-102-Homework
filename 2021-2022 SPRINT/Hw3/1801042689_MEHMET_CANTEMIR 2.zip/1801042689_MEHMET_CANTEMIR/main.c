#include <stdio.h>
int sum(int n1 , int n2 , int flag)
{
	if(n1<n2)         
	{	
		int sumOfNumbers=0;   //variable to add desired numbers
		if(flag == 0)	// addition with even numbers
		{
			if(n1%2==0)		// If the first number is an even number, we will start to add with that number.
			{
				printf("%d ",n1);
				for(int i=n1 ; i<n2 ; i++)
				{
					sumOfNumbers+=i;
					if(i+2<n2)
					{
						printf("+ %d " ,i+2);	
					}
					i++;
				}
			}
			else // If the first number is an odd number, it is the part where we will start adding with that number.
			{
				printf("%d ",n1+1);
				for(int i=n1+1 ; i<n2 ;i++)
				{
					
					sumOfNumbers+=i;	
					if(i+2<n2)
					{
						printf("+ %d " ,i+2);	
					}
					i++;	
				}
			}

			return sumOfNumbers;
		}

		else if (flag==1) 	// addition with odd numbers
		{
			if(n1%2!=0)   // If the first number is an odd number, it is the part where we will start adding with that number.
 			{	
				printf("%d ",n1);

				for(int i=n1 ; i<n2;i++)
				{
					sumOfNumbers+=i;		
					if(i+2<n2)
					{
						printf("+ %d " ,i+2);	
					}
					i++;
				}

			}

			else // If the first number is an odd number, it is the part where we will start adding with that number. 
			{
				printf("%d ",n1+1);
				for(int i=n1+1 ;i<n2;i++)
				{
					sumOfNumbers+=i;
					if(i+2<n2)
					{
						printf("+ %d " ,i+2);	
					}
					i++;	
				}
			}

			return sumOfNumbers;
		}
	}

}
  // ----------------   Operations in the multi and sum functions are similar --------------- 
int multi(int n1 , int n2 , int flag)
{

	if(n1<n2)
	{	
		int multiOfNumbers=1;
		if(flag == 0)
		{
			if(n1%2==0)
			{
				printf("%d ",n1);
				for(int i=n1 ; i<n2 ; i++)
				{
					multiOfNumbers*=i;
					if(i+2<n2)
					{
						printf("* %d " ,i+2);	
					}
					i++;
				}
			}
			else
			{
				printf("%d ",n1+1);
				for(int i=n1+1 ; i<n2 ;i++)
				{
					
					multiOfNumbers*=i;	
					if(i+2<n2)
					{
						printf("* %d " ,i+2);	
					}
					i++;	
				}
			}

			return multiOfNumbers;
		}

		else if (flag==1)
		{
			if(n1%2!=0)
			{	
				printf("%d ",n1);

				for(int i=n1 ; i<n2;i++)
				{
					multiOfNumbers*=i;		
					if(i+2<n2)
					{
						printf("* %d " ,i+2);	
					}
					i++;
				}

			}

			else 
			{
				printf("%d ",n1+1);
				for(int i=n1+1 ;i<n2;i++)
				{
					multiOfNumbers*=i;
					if(i+2<n2)
					{
						printf("* %d " ,i+2);	
					}
					i++;	
				}
			}

			return multiOfNumbers;
		}
	}
}

int isprime (int a)
{	// We check if the number is prime and if not, we increment any variable and return it to main. If it is prime, the variable returns 0.
	int ret=0;
	for(int i=2 ; i<a;i++)
	{
		
		if(a%i==0)
		{
			ret++;
		}
	}

	return ret;
}

void write_file(int number)
{
	FILE *write_number=fopen("results.txt","w");
	fprintf(write_number,"%d",number);
}

void print_file()
{	
	int number;

	FILE *print=fopen("results.txt","r");
	while(!feof(print))
	{
		fscanf(print,"%d",&number);
		printf("%d ",number);	
	}
	
}

void sort_file()//everything is not working correctly in this function. I think it went right as an algorithm, but I couldn't find the error.
{

	int min1 , min2 , min3,count=0,temp,temp1,temp2;
	FILE *read=fopen("results.txt","r+"); //  First, it opens the numbers in the results.txt to read the contents with "read".
	FILE *tempp=fopen("temp.txt","w+");   //  Secondly, the temp.txt file is created to make our work easier.
	FILE *read1=fopen("results.txt","r+"); //Thirdly, As a result, we open the result.txt with the name "read1" to read it a second time.
											// This is because it will take the first 3 numbers and assign them to the "min1 min2 min3" variables.
											// Afterwards, I want to print all numbers to temp.txt, so I create and open "read2" to get the cursor back.

	fscanf(read,"%d %d %d",&min1,&min2,&min3); 

	// sorting the first 3 numbers received from least to greatest (min 1 < min 2 < min 3)
	if(min3 < min2)                      
	{
		temp1 = min2;
		min2 = min3;
		min3 = temp1;
	}
	if(min3 < min1)
	{
		temp1 = min1;
		min1 = min3;
		min3 = temp1;	
	}
	if(min2 < min1)
	{
		temp1 = min1;
		min1 = min2 ;
		min2=temp1;
	}

	//The numbers in the results.txt file are transferred to the tempp.txt file and count how many numbers are in it.

	while(!feof(read1))
	{
		fscanf(read1,"%d",&temp);
			
		fprintf(tempp,"%d ",temp);
		count++;
	}
	FILE *tempRead =fopen("temp.txt","r+");
	FILE *deleteResults = fopen("results.txt","w+");//Resetting the file to print the sorted version to the results.txt file.
	char c='*';
	for(int i=0;i<count;i++)  //With this loop, it is requested to return as many loops as the number of elements.
	{
		while(!feof(tempRead))   //temp.txt is read with a while loop until the end of the file and the numbers are assigned to the temp variable in order
		{	

			fscanf(tempRead,"%d",&temp);
			printf("%d",temp);
			if(temp!=min1 || temp!=min2 || temp!=min3)  //It is checked whether the number assigned to the temp variable is the same as the values of the min 1 , min 2 and min3 variables . If it is different from all of them, the condition is entered.
			{
				
				if(temp<min3)   // The number that is different is compared with the min3, min2 and min1 values and the smallest 3 numbers are found.
				{
					min3=temp;

				
					if(min3<min2)
					{
						temp = min2;
						min2 = min3;
						min3 = temp;
						if(min2<min1)
						{	
							temp=min1;
							min1=min2;
							min2=temp;
						}		
					}
				}
			}
			
			fprintf(deleteResults,"%d %d %d ",min1, min2 ,min3); //The smallest 3 numbers found are printed to the result.txt file.
			
			while(!feof(tempp))   // Then, "*" is printed instead of the values that are the same as min1 min2 min3 numbers
			{

				fscanf(tempp,"%d",&temp);
				if(temp==min1 || temp==min2 || temp==min3)
				{
					fprintf(tempp,"%c",c);
				}	
			}

			fscanf(tempp,"%d %d %d",&min1,&min2,&min3); //Then, the next 3 numbers are taken and sorted, and it is asked to find other small numbers with the same operations from the beginning of the loop and print them to the file.
			if(min3 < min2)
			{
				temp1 = min2;
				min2 = min3;
				min3 = temp1;
			}
			if(min3 < min1)
			{
				temp1 = min1;
				min1 = min3;
				min3 = temp1;	
			}
			if(min2 < min1)
			{
				temp1 = min1;
				min1 = min2 ;
				min2=temp1;
			}
		
		}
	}
}
int main()
{
	int selected;  //choice
	printf("Select operation : \n");                            
	printf("1. Calculate sum/multiplication between two numbers  \n");
	printf("2. Calculate prime numbers\n");
	printf("3. Show number sequence in file \n");
	printf("4. Sort number sequence in file \n");

	scanf("%d",&selected);  
	while(selected<1 || selected>4)  //if selected variable is not 1 between 4 , this is entered in while loop.
	{
		printf("Enter the true selection : ");
		scanf("%d",&selected);
	}

	if(selected==1)		// if  selected 1 , necessary actions are taken
	{
		int operation ,  // variable that species what action to take
		 type_of_number , // variable that specifies whether odd or even operations will be performed
		 number1 , number2;  // numbers to be processed

		printf("Please enter '0' for sum , '1' for multiplication\n");
		scanf("%d",&operation);                                              // where to choose addition or multiplication. 0 : addition 1 : multiplication
		while(operation<0 || operation>1)	
		{
			printf("Please again enter '0' for sum , '1' for multiplication\n");    // If 1 or 0 is not entered, the loop that gives an error and gets the desired numbers again
			scanf("%d",&operation);
		}

		printf("Please enter '0' to work on even numbers , '1' to work on odd numbers\n");
		scanf("%d",&type_of_number);                                           //  where we choose whether to operate with odd or even numbers
		while(type_of_number<0 || type_of_number>1)												
		{
			printf("Please again enter '0' for sum , '1' for multiplication\n");    // If 1 or 0 is not entered, the loop that gives an error and gets the desired numbers again
			scanf("%d",&type_of_number);
		}

		printf("Please enter two different number : \n"); 
		printf("Number 1: ");
		scanf("%d",&number1);	//Entered number 1
		while(number1<0) 		 //loop to enter if number is not positive
		{
			printf("Please enter a number greater than 0 :" );
			scanf("%d",&number1);
		}

		printf("Number 2: "); //Entered number 2
		scanf("%d",&number2);


		while(number2<0 || number2==number1)   //If the variable number2 is less than or equal to number1, it enters this loop and makes it take a larger value.
		{
			printf("Please enter a number greater than number1 :" );
			scanf("%d",&number2);
		}
		
		
		if(operation==0)  // place of addition
		{
			int sumOfNumbers = sum(number1,number2,type_of_number); //function to perform
			printf(" = %d",sumOfNumbers);	
			write_file(sumOfNumbers); // function that prints the returned value to the results.txt file
			printf("\nThe result is written to the results.txt file.");
		}
		else if(operation==1) //place of multiplication
		{
			int multiOfNumbers = multi(number1,number2,type_of_number);   //function to perform
			printf(" = %d",multiOfNumbers);
			write_file(multiOfNumbers);				// function that prints the returned value to the results.txt file
			printf("\nThe result is written to the results.txt file.");
		}

	}

	else if (selected==2) // if  selected 1 , necessary actions are taken
	{	int number;
		printf("Please enter an integer: ");
		scanf("%d",&number);   //entered number
		while(number<0)            //   Loop to enter positive integer if number is not positive integer
		{
			printf("Please enter an positive integer number : ");
			scanf("%d",&number);
		}
		printf("\n");


		for(int i=2 ;i<=number;i++)  // The loop in which we take all the numbers from 2 to the entered number and check each one as a prime number.
		{
			int prime = isprime(i);  //If the incoming number is 0, we indicate that the number is prime. If not, we find how the number is divided and print it.
			if(prime==0)
			{
				printf("%d is prime \n",i);
			}
			else 
			{	
				int tempk=0;

				for (int k = 2; k <= i; k++)
				{		
					if(i%k==0)
					{
							tempk=k;
							k=i;
					}						
						
				}

				printf("%d is not a prime number , it is dividible by %d\n",i,tempk);
			}
		}
	}

	else if (selected==3)
	{
		print_file(); //Printing the data in the results.txt file to the screen
	}

	else if(selected==4)
	{
		sort_file(); //function to sort numbers in file from least to greatest
	}
	return 0;
}