#include <stdio.h>
#include <stdlib.h>
#define STACK_BLOCK_SIZE 10

typedef struct { 
	struct stack *array ;
	int currentsize;
	int maxsize
	}stack;

int push(stack * s , int d); 

void pop(stack * s);

stack *init_return();
int init (stack *s);
int main()
{	
	 stack *n1;
	n1=(stack *)malloc(sizeof(stack));
	
	printf("Enter the Tower size : ");
	scanf("%d",&n1->maxsize);
	return 0;
}