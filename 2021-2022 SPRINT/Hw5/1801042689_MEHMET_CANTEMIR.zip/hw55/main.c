#include <stdio.h>
#include <math.h>

typedef enum     //  shapes to choose
{
	triangle=1,
	quadrilateral,
	circle,
	pyramid,
	cylinder
}shape;
typedef enum    // calculators to choose
{
	area =1 ,
	perimeter,
	volume
}calculators;
int calc_triangle(int calc)
{
	int side1 , side2 , side3 ;
	printf("Please enter three sides of Triangle : \n");  //entered three side


	//Checking if a value other than a number is entered and entered
	while(scanf("%d",&side1)==0)
	{
		printf("ERROR ! Please enter a valid entry. \n");	
		side1=getchar();

	}
	
	while(scanf("%d",&side2)==0)
	{
		printf("ERROR ! Please enter a valid entry. \n");	
		side2=getchar();

	}
	
	while(scanf("%d",&side3)==0)
	{
		printf("ERROR ! Please enter a valid entry. \n");	
		side3=getchar();

	}
	

	while(side1 <= 0 || side2 <= 0 || side3 <= 0)  //Checking whether the edge lengths are zero and small
	{
		printf("ERROR ! Please enter a valid entry. \n");

		//Checking if a value other than a number is entered and entered

		while(scanf("%d",&side1)==0)
		{
			printf("ERROR ! Please enter a valid entry. \n");	
			side1=getchar();

		}
		while(scanf("%d",&side2)==0)
		{
			printf("ERROR ! Please enter a valid entry. \n");	
			side2=getchar();
		}
		
		while(scanf("%d",&side3)==0)
		{	
			printf("ERROR ! Please enter a valid entry. \n");	
			side3=getchar();
		}
	}

	double sum1=side1 + side2 , sum2 = side1 + side3 , sum3 = side2 + side3;
	while(side3 >= sum1 || side2 >= sum2 || side1 >=sum3)  //// The probability of two side lengths being greater than the other is checked
	{
		printf("ERROR ! Please enter a valid entry. \n");
		
		//Checking if a value other than a number is entered and entered
		
		while(scanf("%d",&side1)==0)
		{
			printf("ERROR ! Please enter a valid entry. \n");	
			side1=getchar();

		}

		while(scanf("%d",&side2)==0)
		{
			printf("ERROR ! Please enter a valid entry. \n");	
			side2=getchar();
		}
		
		while(scanf("%d",&side3)==0)
		{
			printf("ERROR ! Please enter a valid entry. \n");	
			side3=getchar();
		}

		sum1 = side1 + side2;
		sum2 = side1 + side3;
	    sum3 = side2 + side3;
	}

	switch(calc)
	{
		// calculated area
		case 1:
   		double temp1 , temp2 , temp3;
		double s = (side1+side2+side3);
		s=s/2;
		double area = (s*(s-side1)*(s-side2)*(s-side3));
		temp1=s-side1;
		temp2=s-side2;
		temp3=s-side3;
		area=s*temp1*temp2*temp3;
		area=sqrt(area);
		printf("Area of TRIANGLE : %.2lf",area);
		break;

		//calculated perimeter
		case 2: 
		double perimeter= side1+side2+side3;
		printf("Perimeter of TRIANGE : %.2lf",perimeter);
		break;
	}
}
int calc_quadrilateral(int calc)
{
	// Entered four side
	int side1 , side2 , side3 ,side4 ;
	printf("Please enter four sides of Quadrilateral : \n");


	//Checking if a value other than a number is entered and entered

	while(scanf("%d",&side1)==0)
	{
		printf("ERROR ! Please enter a valid entry. \n");	
		side1=getchar();
	}
	while(scanf("%d",&side2)==0)
	{
		printf("ERROR ! Please enter a valid entry. \n");	
		side2=getchar();

	}
	
	while(scanf("%d",&side3)==0)
	{
		printf("ERROR ! Please enter a valid entry. \n");	
		side3=getchar();
	}
	
	while(scanf("%d",&side4)==0)
	{
		printf("ERROR ! Please enter a valid entry. \n");	
		side4=getchar();
	}


	//Checking whether the edge lengths are zero and small
	while(side1<=0 || side2<=0 || side3<=0 || side4<=0)
	{
		printf("ERROR ! Please enter a valid entry: \n");
	
		//Checking if a value other than a number is entered and entered

		while(scanf("%d",&side1)==0)
		{	
			printf("ERROR ! Please enter a valid entry. \n");	
			side1=getchar();
		}
		
		while(scanf("%d",&side2)==0)
		{
			printf("ERROR ! Please enter a valid entry. \n");	
			side2=getchar();
		}
		while(scanf("%d",&side3)==0)
		{
			printf("ERROR ! Please enter a valid entry. \n");	
			side3=getchar();
		}
		while(scanf("%d",&side4)==0)
		{
			printf("ERROR ! Please enter a valid entry. \n");	
			side4=getchar();
		}

	}
	switch(calc)
	{
		//calculated area
		case 1: 
		double s =(side1+side2+side3+side4);
		s=s/2;
		double temp1 , temp2 , temp3 , temp4;
		temp1=s-side1;
		temp2=s-side2;
		temp3=s-side3;
		temp4=s-side4;
		double area= temp1*temp2*temp3*temp4;
		area=sqrt(area);
		

		printf("Area of QUADRILATERAL : %.2lf",area);
		break;

		//calculated perimeter
		case 2:
		double perimeter = side1+side2+side3+side4;
		
		printf("Perimeter of QUADRILATERAL : %.2lf ",perimeter);
		break;

	}
}
int calc_circle(int calc)
{
	double pi = 3.14;  //pi value
	//Entered radius value
	double r;          
	printf("Please enter the radius of Circle : ");
	
	//Checking if a value other than a number is entered and entered

	while(scanf("%d",&r)==0)
	{
		printf("ERROR ! Please enter a valid entry. \n");	
		r=getchar();

	}
	while(r<=0)	//Checking whether the edge lengths are zero and small
	{
		printf("ERROR ! Please enter a valid entry\n");
		scanf("%lf",&r);
	}
	switch(calc)
	{	
		//Calculated area
		case 1: 
		double area = pi * r * r;
		printf("Area of CIRCLE : %.2lf",area);
		break;


		//Calculated perimeter
		case 2:
		double circumference = 2 * pi * r;
		printf("Area of CIRCUMFERENCE : %.2lf",circumference);
		break;
	}
}
int calc_pyramid(int calc)
{	
	double side,slant,height;
	switch(calc)
	{
		//calculated area
		case 1:
		printf("Please enter the base side and slant height of a Pyramid :\n ");
		
		//Checking if a value other than a number is entered and entered
		while(scanf("%d",&side)==0)
		{
			printf("ERROR ! Please enter a valid entry. \n");	
			side=getchar();
		}
		while(scanf("%d",&slant)==0)
		{
			printf("ERROR ! Please enter a valid entry. \n");	
			slant=getchar();
		}
		while(side <= 0 || slant <= 0)  //Checking whether the edge lengths are zero and small
		{
			printf("ERROR ! Please enter a valid entry. \n");

			//Checking if a value other than a number is entered and entered
			while(scanf("%d",&side)==0)
			{
				printf("ERROR ! Please enter a valid entry. \n");	
				side=getchar();
			}
			while(scanf("%d",&slant)==0)
			{
				printf("ERROR ! Please enter a valid entry. \n");	
				slant=getchar();
			}
			
		}
		double b = side*side;
		printf("Base Surface Area of a PYRAMID : %.2lf   \n",b);
		double l=2*side*slant;
		printf("Lateral Surface Area of a PYRAMID : %.2lf \n",l);
		double surface = b +l;
		printf("Surface Area of PYRAMID  : %.2lf",surface);
		break;

		//calculated volume
		case 3:
		printf("Please enter the base side and height of a Pyramid : \n");
	
		//Checking if a value other than a number is entered and entered
		while(scanf("%d",&side)==0)
		{
			printf("ERROR ! Please enter a valid entry. \n");	
			side=getchar();
		}
		while(scanf("%d",&height)==0)
		{
			printf("ERROR ! Please enter a valid entry. \n");	
			height=getchar();
		}
		while(side <= 0 || height <= 0)  //Checking whether the edge lengths are zero and small
		{
			printf("ERROR ! Please enter a valid entry. \n");

			//Checking if a value other than a number is entered and entered
			while(scanf("%d",&side)==0)
			{
				printf("ERROR ! Please enter a valid entry. \n");	
				side=getchar();
			}
			while(scanf("%d",&height)==0)
			{
				printf("ERROR ! Please enter a valid entry. \n");	
				height=getchar();
			}
			
		}
		double volume = side*side;
		volume*=height;
		volume/=3;
		printf("Volume of a PYRAMID : %.2lf",volume);	
		break;
	}
}
int calc_cylinder(int calc)
{
	double pi=3.14,r,h;


	switch(calc)
	{
		//calculated area
		case 1:
		printf("Please enter the radius and height of a Cylinder: \n");

		//Checking if a value other than a number is entered and entered
		while(scanf("%d",&r)==0)
		{
			printf("ERROR ! Please enter a valid entry. \n");	
			r=getchar();
		}
		while(scanf("%d",&h)==0)
		{
			printf("ERROR ! Please enter a valid entry. \n");	
			h=getchar();
		}
		while(r<=0 || h<=0)
		{
			printf("ERROR ! Please enter a valid entry\n");

			//Checking if a value other than a number is entered and entered
			while(scanf("%d",&r)==0)
			{
				printf("ERROR ! Please enter a valid entry. \n");	
				r=getchar();
			}
			while(scanf("%d",&h)==0)
			{	
				printf("ERROR ! Please enter a valid entry. \n");	
				h=getchar();
			}

		}
		double b=pi*r;
		b*=r;
		printf("Base Surface Area of a CYLINDER: %.2lf \n",b);

		double l= 2*pi;
		l*=r*h;
		printf("Lateral Surface Area of a CYLINDER : %.2lf\n",l);

		double surface = r+h;
		surface*=2*pi*r;
		printf("Surface Area of CYLINDER  : %.2lf",surface);
		break;


		//calculated volume
		case 3:
		printf("Please enter the radius and height of a Cylinder \n");
		
		//Checking if a value other than a number is entered and entered
		while(scanf("%d",&r)==0)
		{
			printf("ERROR ! Please enter a valid entry. \n");	
			r=getchar();
		}
		while(scanf("%d",&h)==0)
		{
			printf("ERROR ! Please enter a valid entry. \n");	
			h=getchar();
		}
		while(r<=0 || h<=0)
		{
			printf("ERROR ! Please enter a valid entry\n");
			
			//Checking if a value other than a number is entered and entered
			while(scanf("%d",&r)==0)
			{
				printf("ERROR ! Please enter a valid entry. \n");	
				r=getchar();
			}
			while(scanf("%d",&h)==0)
			{
				printf("ERROR ! Please enter a valid entry. \n");	
				h=getchar();
			}

		}
		double volume= pi*r*r*h;
		printf("Volume of a CYLINDER : %.2lf",volume);
	}
}	
int select_shape()   //   selected shape
{	
	shape shapes; 
	printf("Select a shape to calculate: \n");
	printf("---------------------------- \n");
	printf("1. Triangle \n");
	printf("2. Quadrilateral \n");
	printf("3. Circle \n");
	printf("4. Pyramid \n");
	printf("5. Cylinder \n");
	printf("0. Exit \n");
	scanf("%d",&shapes);
	while(shapes<0 || shapes>5 )	// In the menu of figure selection, there are options defined in indexes 0 to 5. If numbers other than these are entered, an error is given
	{
		printf("ERROR ! Please enter a valid entry\n");
		printf("1. Triangle \n");
		printf("2. Quadrilateral \n");
		printf("3. Circle \n");
		printf("4. Pyramid \n");
		printf("5. Cylinder \n");
		printf("0. Exit \n");
		scanf("%d",&shapes);
	}

	if(shapes==0)   // If 0 is entered , the program exits.
	{
		printf("\n\nExited the program.");
		return shapes;
	}
	else
	{
		return shapes;
	}
}
int select_calc()
{
	calculators calculate ;

	
	printf("Select calculator: \n");
	printf("---------------------------- \n");
	printf("1. Area \n");
	printf("2. Perimeter \n");
	printf("3. Volume \n");
	printf("0. Exit \n");
	scanf("%d",&calculate);
	while(calculate<0 || calculate>3) // In the menu of figure selection, there are options defined in indexes 0 to . If numbers other than these are entered, an error is given
	{
		printf("ERROR ! Please enter a valid entry\n");
		printf("1. Area \n");
		printf("2. Perimeter \n");
		printf("3. Volume \n");
		printf("0. Exit \n");
		scanf("%d",&calculate);
	}

	if(calculate==0)
	{
		printf("Exited the program.");
		return calculate;
	}
	else
	{
		return calculate;	
	}	
}
int calculate(int shape , int calc)
{
	double conclusion;
	switch(shape)
	{
		case 1 :
		conclusion = calc_triangle(calc);  //calculated triangle
		break;

 		case 2 :
 		conclusion = calc_quadrilateral(calc);  //calculated quadrilateral
		break;

		case 3 :
		conclusion = calc_circle(calc);  // calculated circle
		break;

		case 4 :
		conclusion = calc_pyramid(calc);  // calculated pyramid
		break;

		case 5 :
		conclusion = calc_cylinder(calc);  // calculated cylinder
		break;

	}
	return conclusion;
}
int main()
{	
	printf("Welcome to the geometric calculator! \n");
	int s_shape , s_calc ;
	double calc;
	s_shape=select_shape(); // the function from which the shape is selected and the variable that will take the value when it returns
	if(s_shape!=0)
	{	
		s_calc=select_calc();
		if(s_calc!=0)
		{  

		    // In case the shape is determined, the action to be taken about that shape.

			//The part that states that some actions are performed in some ways
			while(s_shape == 2 && s_calc == 3)
			{
				printf("ERROR ! You cannot calculate the volume of a Quadrilateral. Please try again\n");
				s_shape=select_shape();

				if(s_shape!=0)
					s_calc=select_calc();	
						
			}

			while(s_shape == 1 && s_calc == 3)
			{
				printf("ERROR ! You cannot calculate the volume of a triangle. Please try again\n");
						
				s_shape=select_shape();	
				if(s_shape!=0)
					s_calc=select_calc();	
			}

			while(s_shape == 3 && s_calc == 3)
			{
				printf("ERROR ! You cannot calculate the volume of a circle. Please try again\n");
				s_shape=select_shape();	
				if(s_shape!=0)
					s_calc=select_calc();		
			}

			while(s_shape == 4 && s_calc == 2)
			{
				printf("ERROR ! You cannot calculate the permeter of a pyramid. Please try again\n");
				s_shape=select_shape();	
				if(s_shape!=0)
					s_calc=select_calc();	
			}

			while(s_shape == 5 && s_calc == 2)
			{
				printf("ERROR ! You cannot calculate the permeter of a pyramid. Please try again\n");
				s_shape=select_shape();	
				if(s_shape!=0)	
					s_calc=select_calc();
			}	

			if(s_calc!=0)
				calc = calculate(s_shape ,s_calc); //Where calculations are made
		}
	}	
	
	return 0;
}