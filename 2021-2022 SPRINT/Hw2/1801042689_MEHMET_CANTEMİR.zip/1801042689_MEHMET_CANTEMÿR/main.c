#include <stdio.h>
#include <stdlib.h>
#include "util.h"
#include <math.h>


int main() {


    int p ;
    char p1_a, p1_b;
    double PL ,PW ;
    /* Ask for the problem selection (1,2,3) .....  */
    printf("Enter the problem selection (1,2,3) : ");
    scanf("%d",&p);
    while(p<1 || p>3)
    {
        printf("Please enter the selection numbers 1 ,2 or 3: ");
        scanf("%d",&p);
    }

  
     
   
    if(p==1)
    {   
        printf("Enter the PL : ");
        scanf("%lf",&PL);

        printf("Enter the PW : ");
        scanf("%lf",&PW);
        p1_a= dt1a(PL,PW);
        if(p1_a=='s')
        {
            printf(" P1 First Decision is : Setosa");
        }

        else if(p1_a=='v')
        {
            printf(" P1 First Decision is : Virginica");
        }

        else if(p1_a=='z')
        {
            printf(" P1 First Decision is : Versicolor");
        }
        else
        {
            printf("P1 First Decision is : NULL ");
        }

        printf("\n");
        p1_b= dt1b(PL,PW);

        if(p1_b=='s')
        {
            printf(" P1 Second Decision is : Setosa");
        }

        else if(p1_b=='v')
        {
            printf(" P1 Second Decision is : Virginica");
        }

        else if(p1_b=='z')
        {
            printf(" P1 Second Decision is : Versicolor");
        }
        else
        {
            printf("P1 Second Decision is : NULL ");
        }

    }

    else if(p==2)
    {   
        double x1 , x2 , x3, r,r1 ;
    
        int  x4,x5;
        printf("Enter the x1 : ");
        scanf("%lf",&x1);
    
        printf("Enter the x2 : ");
        scanf("%lf",&x2);

        printf("Enter the x3 : ");
        scanf("%lf",&x3);

        printf("Enter the x4 : ");
        scanf("%d",&x4);
        if(x4<0 && x4 >1)
        {
            printf("Please enter the 0 or 1 (0 = False 1 = True");
            scanf("%d",&x4);
        }
    

        printf("Enter the x5 : ");
        scanf("%d",&x5);
        if(x5<0 && x5>1)
        {
            printf("Please enter the 0 or 1 (0 = False 1 = True");
            scanf("%d",&x5);
        }

        r=dt2a(x1,x2,x3,x4,x5);
        r1=dt2b(x1,x2,x3,x4,x5);
    
        printf(" \n \n  DT2A : %.2lf",r);
        printf(" \n \n  DT2B : %.2lf",r1);
    }

    else if (p==3)
    {
        int age , mental_healthy ,phsical_healthy ,gender;
        double cm , kg ;
        

        printf("Enter the age : ");
        scanf("%d",&age);

        printf("Enter the mental status (0 or 1) : ");
        scanf("%d",&mental_healthy);
        while(mental_healthy<0 ||mental_healthy>1)
        {
            printf("Please enter the 0 or 1 : ");
            scanf("%d",&mental_healthy);
        }

        printf("Enter the phsical status (0 or 1) : ");
        scanf("%d",&phsical_healthy);
        while(phsical_healthy<0 ||phsical_healthy>1)
        {
            printf("Please enter the 0 or 1 : ");
            scanf("%d",&phsical_healthy);
        }        

        printf("Enter the cm : ");
        scanf("%lf",&cm);

        printf("Enter the kg : ");
        scanf("%lf",&kg);

        printf("Enter the gender 1 or 0:");
        scanf("%d",&gender);
        
        printf("\n*************** DT3A ************************ \n\n");
               
        dt3a(age,mental_healthy,phsical_healthy,cm,kg,gender);



        printf("\n*************** DT3B ************************ \n\n");
        dt3b(age,mental_healthy,phsical_healthy,cm,kg,gender);
        
    }



    

    return 0;
}
