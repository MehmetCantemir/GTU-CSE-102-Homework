#include <stdio.h>
#include "util.h"
#include <math.h>


/* Example decision tree - see the HW2 description */
/*
int dt0(int t, double p, double h, int s, int w) {
    int r = 0;
    if (t>35 && w!=3) r = 1;
    else if (t<=35 && s==0) r = 1;
    return r;
}
*/

/* Provide your implementations for all the requested functions here */

char dt1a( double PL , double PW)
{
    char w;   // The variable of the value to return as a result of the conditions.
    if(PL<2.45)
    {
        w='s'; // s = setosa
        return w;

    }
    else
    {
        if(PW>1.75)
        {
            w='v'; // v = verginica
            return w;
        }
        else if(PL<4.95 && PW<1.65)
        {
            w='z'; // z = versicolor
            return w;

        }
        else
        {
            w='v';
            return w;
        }

    }
}

char dt1b( double PL , double PW)
{
   char x ;  // The variable of the value to return as a result of the conditions.
   if(PL<2.55)
   {
        x='s';   // s = Setosa
        return x;
   } 
   else
   {
        if(PW>1.69)
        {
            x='v' ; // v = Virginica
            return x;
        }
        else
        {
            if(PL<4.85)
            {
                x='z' ; // z = Versicolor
                return x;
            }
            else
            {
                x='v' ; // v = Virginica
                return x;
            }
        }
    
   }
}

double dt2a(double x1 ,double x2 ,double x3,int x4 , int x5)
{
    //Conditions as given
    if(x1<31.5)
    {
        if(x2>-2.5)
        {
            return 5.0;
        }
        else
        {
            if((x2-0.1)<=x1 && x1<=(x2+0.1))
            {
                return 2.1;
            }
            else
            {
                return -1.1;
            }
        }
    }
    else
    {
        if (x3>=-1 && x3<=2)
        {
            return 1.4;
        }
        else
        {
            if(x4 && x5)
            {   
                return -2.23;
            }   
            else
            {
                return 11;
            }   
        }
    }
}
double dt2b(double x1 ,double x2 ,double x3,int x4 , int x5)
{

    //Conditions as given
    if(x1>12 && x1<22)
    {
        if (x3>(5/3))
        {
            return -2.0;
        }
        else
        {
            if((x1-0.1)<=x3 && x3<=(x1+0.1))
            {
                return 1.01;
            }
            else
            {
                return -8;
            }
        }
    }
    else
    {
        if (x4&&x5)
        {
            return -1;
        }
        else
        {
            if(x2>=-1 && x2<=2)
            {
                double a= -1, b=7;
                double j = a/b;
                return j;
            }
            else
            {
                double k;
                k=sqrt(2)/3;
                return k;
            }
        }
    }

}

//In this problem, military service inquiries and school status inquiries are made.
void dt3a(int age , int mh,int ph , double cm , double kg , int g)
{
    if (age>18) //aged is questioned.
    {
       if(g==1) //gender is questioned. If it is 1, it is a boy; otherwise, it is a girl.
       {
            if (kg>55.7 && kg<115.9) //weight is guestioned
            {
                if (cm>1.55 && cm<2.15) //height is questioned
                     {
                         if(mh && ph)  //mental and physical health is questioned. If the value is 1, the individual is healthy, otherwise he is unhealthy.
                         {
                            printf("He can join the army");
                         }
                         else printf("He has a physical or mental illness and can not join the military");

                     }   
                else printf("He can't go to the military if he is not the desired height");

            }
            else printf("He can't go to the military if he is not the desired weight");
                
       }
       else printf("Only men go to the military");
    }  

    //values are similarly in if blocks. 
    else
    {   
        printf("\n\nPersons under the age of 18 cannot enlist in the military.\n");
        if(age>13 && age <=17)
        {
            if (kg>=40.5 && kg<=115.5)
            {
                if(cm>0.75 && cm<2.15)
                {   
                    if (mh && ph)
                    {
                        printf("Can go to high school");
                    }
                    else printf("He/She has a physical or mental illness and can not join the high school");

                }   
                else printf("insufficient height to go to high school");

            }
            else printf("insufficient kilograms to go to high school");
        }
        else
        {
            if (age>=7 && age<13)
            {
                printf("Can go to primary school");
            }
            else
            {
                printf("he/she is baby");
            }
        }

    }
}
//In this problem, participation in football teams is questioned. 
void dt3b(int age , int mh,int ph , double cm , double kg , int g)
{

    // Values are similarly in dt3a function.
    if(age<=12)
    {
        if(g)
        {
            if(kg>=30 &&  kg<=70)
            {
                if (cm>=1.45 && cm<=1.75)
                {
                    if(mh&ph)
                    {
                        printf("He can join the junior boy's team");
                    }
                    else
                    {
                        printf("Cant join junior boy's team");
                    }
                }
                else
                {
                    printf("Cant join junior boy's team");       
                }
            }
            else
            {
                printf("Cant join junior boy's team");
            }
        }
        else
        {
            if (kg>=30 && kg<=55)
            {
                if(cm>=1.45 && cm<=1.65)
                {
                    if (mh && ph)
                    {
                        printf("She can join women's soccer team");
                    }
                    else
                    {
                        printf("She can't women's soccer team");
                    }
                }
                else
                {
                    printf("She can't women's soccer team");       
                }
            }
            else
            {
                printf("She can't women's soccer team");
            }
        }
    }
    else if(age<=15)
    {
        if(g)
        {
            if(kg>=50 && kg<=80)
            {
                if(cm>=1.45 && cm<1.86)
                {
                    if (mh && ph)
                    {
                        printf("He can join middle-aged men's soccer team");
                    }
                    else{
                        printf("Cannot join any team");
                    }
                }
                else
                {
                    printf("Cannot join any team");
                }
            }
            else
            {
                printf("Cannot join any team");
            }             
        }
        else
        {
            printf("Cannot join any team");
        }
    }
    else
    {
        printf("Cannot join any team");
    }
}