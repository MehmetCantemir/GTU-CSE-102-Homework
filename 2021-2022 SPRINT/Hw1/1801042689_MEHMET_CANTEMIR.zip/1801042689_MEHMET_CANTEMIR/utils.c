#include <stdio.h>
#include "utils.h"


int find_divisible(int x , int y , int z)  // dividing the numbers between the x and y numbers by z
{	
	int f_l; // returned number 
	int numbers[y]; // Array variable to assign numbers dividing by z between x and y
	if(x>y || x==y)  // if x is greater than or equal to y , -1 is returned
	{
		return -1;
	}
	else
	{
		int count=0; // arrays number

		for(int i=x ; i<y;i++)  // finding divisible numbers
		{
			if(i%z==0)
			{
				numbers[count]=i;
				count++;
			}
		}
	}
	f_l=numbers[0];  //  the first number divided is returned
	return f_l;

}


int find_nth_divisible(int n, int f_l, int z)  //it finds the number in the desired step and returns it
{

	for (int i=0;i<n;i++)  
	{
		f_l+=z;
	}
	return f_l;
}



int validate_identity_number(char identity_number[])
{
	int id_number[11];

	if(identity_number[0]=='0') // Checking whether the first digit in the TC number is 0 or not
	{
		return 0; //returned 0
	}
	else
	{
		
		for(int i=0;i<11;i++) // char convert to int
		{
			if(identity_number[i]=='0')
			{
				id_number[i]=0;
			}
			else if(identity_number[i]=='1')
			{
				id_number[i]=1;
			}
			else if(identity_number[i]=='2')
			{
				id_number[i]=2;
			}
			else if(identity_number[i]=='3')
			{
				id_number[i]=3;
			}
			else if(identity_number[i]=='4')
			{
				id_number[i]=4;
			}
			else if(identity_number[i]=='5')
			{
				id_number[i]=5;
			}
			else if(identity_number[i]=='6')
			{
				id_number[i]=6;
			}
			else if(identity_number[i]=='7')
			{
				id_number[i]=7;
			}
			else if(identity_number[i]=='8')
			{
				id_number[i]=8;
			}
			else if(identity_number[i]=='9')
			{
				id_number[i]=9;
			}
			else
			{
			
			}
		}	
		
	}

	// Checking whether the first digit in the TC number is 0 or not
	int sum1=0 , sum2=0;
	for(int i=0;i<9;i=i+2)
	{
		sum1+=id_number[i];
	}

	for(int i=1;i<9;i=i+2)
	{
		sum2+=id_number[i];
	}

	sum1*=7;
	sum1-=sum2;
	sum1%=10;

	int sum=0;
	for (int i = 0; i < 10;i++)
	{
		sum+=id_number[i];
	}
	sum%=10;

	//Returns 1 if it's legal, 0 otherwise
	if(sum1==id_number[9]&&sum==id_number[10])
	{
		return 1; 
	}
	else
	{
		return 0;
	}
	
}

int create_customer(char identity_number[],int password)
{
	password=1453; // creating user password
	identity_number="62744290802"; // creating user TC
	int k=validate_identity_number(identity_number);//It is checked whether the created TC complies with the rules
	
	// check returned number and password

	if(k==0 && password>9999 && password<1000)
	{
		printf("invalid identity number or password");
	}
	else // If the control is successful, we print the TC and password to the customeraccount.txt file.
	{	

		FILE *fp=fopen("customeraccount.txt","w");
		fprintf(fp, "%s,%d",identity_number,password);
		fclose(fp);	
	}
	
}

int check_login(char identity_number[],int password)
{	
	int control=0; //This is control variable.
	char identity[11]; // The TC in customeraccount.txt
	char passs[4]; // The password in custormeraccount.txt(char)
	int pass[4] ; // The password in custormeraccount.txt(int)
	char temp[16]; //The data in customeraccount.txt
	FILE *fs=fopen("customeraccount.txt","r");
	int j=0 ; //This is counter
	int counter=0;
	
	while(!feof(fs)) // The data in customeraccount.txt is being passed to the temp[] variable.
	{
		fscanf(fs,"%c",&temp[j]);
		j++;
		
		
	}
	fclose(fs);
	
	for(int i=0 ; i<11;i++) // TC information identity[] is discarded.
	{
		identity[i]=temp[i];

	}

	for(int i=0 ; i<11;i++) // Equality comparison of the TC entered by the user and the TC in customeraccount.txt
	{
		if(identity[i]!=identity_number[i])
		{
			control++; // If not equal the control variable will be incremented.
		}
	}	

	
	// The process of converting our password data in customeraccount.txt to int variable
	int k=0;
	for(int i=12 ; i<16;i++)
	{
		passs[k]=temp[i];
		k++;
	}
	
	for(int i=0;i<4;i++)
	{
		if(passs[i]=='0')
		{
			pass[i]=0;
		}
		else if(passs[i]=='1')
		{
			pass[i]=1;
		}
		else if(passs[i]=='2')
		{
			pass[i]=2;
		}
		else if(passs[i]=='3')
		{
			pass[i]=3;
		}
		else if(passs[i]=='4')
		{
			pass[i]=4;
		}
		else if(passs[i]=='5')
		{
			pass[i]=5;
		}
		else if(passs[i]=='6')
		{
			pass[i]=6;
		}
		else if(passs[i]=='7')
		{
			pass[i]=0;
		}
		else if(passs[i]=='8')
		{
			pass[i]=8;
		}
		else if(passs[i]=='9')
		{
			pass[i]=9;
		}
	}
 	 
 	 //We convert the password value into an integer and compare it with the entered value.
	
	int t_password = ((pass[0]*1000)+(pass[1]*100)+(pass[2]*10)+(pass[3]*1));
	if(t_password!=password){
		control++;
	}

	return control; 

}
// If the entered money is multiple of 10,20 and 50 , the function that allows it to be given
int withdrawable_amount(float cash_amount) 
{	
	int cash=(int)cash_amount;
	int k;
	if(cash%10!=0)
	{
		k=cash%10;
		cash-=k;
		return cash;
	}
	else
	{
		return cash;
	}


}

