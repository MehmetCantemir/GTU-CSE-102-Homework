#include <stdio.h>
#include "utils.h"


int main()
{
	/*------------------------ PART 1 -------------------*/
	int x;  // This is beginning number
	int y;  // This is ending number
	int z;  // This is divisor number
	int n ; // This is next number

	printf("Enter the first number: ");   //Entered beginning number
	scanf("%d",&x);

	printf("\nEnter the second number: ");  //Entered ending number
	scanf("%d",&y);
	
	printf("\nEnter the divisor: ");  // Entered divisor number
	scanf("%d",&z);

	int f_l= find_divisible(x,y,z); 
	if(f_l==-1)  // // if x is greater than or equal to y , -1 is returned
	{
		printf("\nThere is not any integer between %d and %d can be divided by %d",x,y,z);
	}


	else
	{	
		if(f_l<=0) 
		{

			printf("\nThere is not any integer between %d and %d can be divided by %d",x,y,z);		
		}

		else
		{
			printf("\nThe first integer between %d  and %d divided by %d is %d\n",x,y,z,f_l);
			printf("\nEnter the number how many next : "); //Entered next number
			scanf("%d",&n); 
			int k=find_nth_divisible(n,f_l,z); // n. function that finds the number
			if(k>y) // If the number found is greater than the ending number , an error is printed
			{
				printf("\n No possible to find %dth divisible between %d and %d divided by %d",n,x,y,z);
			}
			else // the printed in step is printed.
			{
				printf("\nThe %d. integer between %d and %d divided by %d is %d",n+1,x,y,z,k);
			}
		}
	}


	printf("\n\n-------------------END OF PART1 --------------------------------\n\n");
	printf("--------------------------------------------------------------\n\n\n\n");


	/*--------------------- PART2 AND PART3 ---------------------------*/

	char identity_number[11]; // This is TC no
	char entered_identity_number[11]; // TC number entered by the user
	int password;  // This is password
	float cash_amount; // This is amount of money to be withdrawn
	int k=create_customer(identity_number,password); // Creating user information
	printf("\nEnter your identity number : ");
	scanf("%s",entered_identity_number); //Entered users TC 
	
	printf("\nEnter your password: "); //Entered users password
	scanf("%d",&password);
	int check=check_login(entered_identity_number,password); // It is checked whether the entered values are the same as the saved values.
	if(check==0) //login location based on returned value
	{
		printf("\nLogin Succesfull\n");
		printf("\nEnter your withdraw amount: "); //Entered amount of money to be withdrawn
		scanf("%f",&cash_amount);
		int cash=withdrawable_amount(cash_amount); //
		printf("\nWithdrawable amount is : %d ",cash); 
	}
	else
	{
		printf("\nInvalid identity number or password");
	}
	return 0;
}