#include <stdio.h>

#include <stdlib.h>

void generate_sequence(int xs , int currentlen , int seqlen , int *seq)
{
	
	
	if(seqlen!=0)
	{
		if(xs%2==0)
		{
			
			

			*(seq+currentlen)=xs;
			xs=xs/2;
			
		}
		else
		{
			
			*(seq+currentlen)=xs;
			xs=((3*xs)+1);
			
		}
		seqlen--;
		currentlen++;
		generate_sequence(xs ,currentlen , seqlen , seq);
	}
	else
	{
		printf("Sequence: {");
		for(int i=0;i<currentlen;i++)
		{
			printf("%d, ",*(seq+i));
		}
		printf("}");
	}

}

/*void check_loop_iterative(void (*f)(int a , int b , int c , int *k),int xs , int seqlen , int *loop , int *looplen)
{
	int counter=0;
	int counter1 = seqlen/2;
	int counter2=0;
	if (*(loop+0)==4 && *(loop+1)==2 && *(loop+2)==1)
	{
		
	}
	else
	{
		if(counter1!=0)
		{
			*(looplen+counter)=*(k+counter1);
			printf("Checking if there is a loop of length %d...",counter1);
			counter1--;
			counter++;
		}
		
		if(*(looplen+counter)==*(looplen+(counter-3)))
		{	
			*(loop+counter2)=*(looplen+counter);
		}
		
		check_loop_iterative(generate_sequence,xs,seqlen,loop,looplen);
	}
}
*/
/*int has_loop(int *arr , int n , int looplen , int *ls , int *le)
{

	if(seqlen!=0)
	{
		if(xs%2==0)
		{
			
			

			*(arr+currentlen)=xs;
			xs=xs/2;
			
		}
		else
		{
			
			*(arr+currentlen)=xs;
			xs=((3*xs)+1);
			
		}
		seqlen--;
		currentlen++;
		has_loop(arr ,n , seqlen , seq);
	}
	int counter = 0;
	if(*(arr+counter)!=0)
	{
		has_loop(arr,n,looplen,ls,le);
		counter++;	
	}
	printf("%d",counter);
}
*/
void hist_of_firstdigits(int xs , int seqlen , int *h , int digit)
{

}
int main()
{
	int xs,currentlen=0,seqlen;
	printf("Please enter the sequence length : ");
	scanf("%d",&seqlen);
	printf("\nPlease enter the first element : ");
	scanf("%d",&xs);
	int *seq;
	int *looplen , *loop ;
    int *arr;
	looplen = (int *)malloc((seqlen/2)*sizeof(int));
	seq = (int *)malloc(seqlen*sizeof(int));
	loop = (int *)malloc((seqlen/2)*sizeof(int));
	arr = (int *)malloc(seqlen*sizeof(int));
	
	int n , l , *ls , *le; 
	
	generate_sequence(xs ,currentlen , seqlen , seq);
	free(seq);
	//check_loop_iterative(generate_sequence,xs,seqlen,loop,looplen);
	//has_loop(arr,n,l,ls,le);
	//free(arr);


	return 0;
}